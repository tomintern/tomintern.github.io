A Pen created at CodePen.io. You can find this one at http://codepen.io/CosX/pen/jAvYPz.

 I made this a while back for my homepage (http://karlsolgard.net/). I thought you guys might get a kick out of it :) Click the guy and see what he does!