A Pen created at CodePen.io. You can find this one at http://codepen.io/davidkpiano/pen/wMqXea.

 Based on a playful [Dribbble shot by Ryan Rumbolt](https://dribbble.com/shots/2418721-Husky-love) and [illustration by Alexey Kuvaldin](https://dribbble.com/kuvaldin).

Works best in Chrome :)