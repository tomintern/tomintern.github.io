A Pen created at CodePen.io. You can find this one at http://codepen.io/lloydfenton/pen/pbOzVy.

 A homage to the beautiful story of Princess Mononoke by Hayao Miyazaki and Studio Ghibli.
SVG frames are all hand drawn in Adobe Illustrator from a small segment of the movie and animated with CSS Keyframes.

Performance issues may arise on older machines as the animations can be quite CPU intensive.
If you have any suggestions, please do leave them below.

All rights go to Studio Ghibli and Joe Hisaishi for the audio.