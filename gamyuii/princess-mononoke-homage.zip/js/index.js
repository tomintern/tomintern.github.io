$(window).load(function() {
    $('#world').addClass('start');
});